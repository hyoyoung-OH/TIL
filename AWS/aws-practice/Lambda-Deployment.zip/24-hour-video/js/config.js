var configConstants = {
    auth0: {
        domain: 'dev--4qywz24.us.auth0.com', // 본인의 auth0 도메인
        clientId: 'iPEi7RzRGaSUuojtZmMFkwvaHKvQL93z' // 본인의 auth0 클라이언트 ID
    }
};
